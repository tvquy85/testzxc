# 16 — Evidence-Level Counterfactual Faithfulness V6

> Scope: branch `currentdata-aaai-fix-v2`; current-data only; do not use SN2; do not expand full FNSPID. Execute one file at a time. Every step must write a status JSON and must stop on FAIL. Pipeline PASS is not a scientific claim.

## Goal
Improve and test news faithfulness. Medium counterfactual was blocked because positive/negative news perturbations were weak.

## Outputs
```text
outputs/metrics/16_v6_counterfactual_news_evidence.json
outputs/tables/16_v6_counterfactual_breakdown.csv
review_samples/currentdata_v6/16_counterfactual_failure_samples.jsonl
outputs/status/16_COUNTERFACTUAL_NEWS_EVIDENCE_V6.status.json
```

## Tasks
`remove_positive_evidence`, `remove_negative_evidence`, `neutralize_positive_evidence`, `neutralize_negative_evidence`, `remove_all_company_evidence`, `neutralize_bearish_technical`, `neutralize_bullish_technical`.

## Test case
```python
from src.eval.counterfactual_direction_rules_v6 import expected_direction

def test_expected_direction_positive_removed():
    assert expected_direction('remove_positive_evidence') == 'up_decreases'

def test_expected_direction_negative_removed():
    assert expected_direction('remove_negative_evidence') == 'down_decreases'
```

## Commands
```bash
python -m src.eval.build_counterfactual_evidence_v6 --contexts data/processed/ticker_date_evidence_contexts_h1_v6_repaired.parquet --predictions outputs/predictions/current_v6_dpo_predictions.parquet --output data/eval/current_v6_counterfactual_tasks.jsonl --status outputs/status/16A_BUILD_COUNTERFACTUAL_V6.status.json
python -m src.eval.evaluate_counterfactual_directional_v4 --tasks data/eval/current_v6_counterfactual_tasks.jsonl --adapter outputs/models/qwen3_current_v6_dpo_adapter --config configs/local_paths.yaml --metrics outputs/metrics/16_v6_counterfactual_news_evidence.json --breakdown outputs/tables/16_v6_counterfactual_breakdown.csv --failures review_samples/currentdata_v6/16_counterfactual_failure_samples.jsonl --status outputs/status/16_COUNTERFACTUAL_NEWS_EVIDENCE_V6.status.json
python -m pytest -q tests/test_counterfactual_direction_v6.py tests
```

## Acceptance
Overall pass >=0.50 for claim; no-change <=0.35; remove positive/negative evidence >=0.35; schema >=0.90.
