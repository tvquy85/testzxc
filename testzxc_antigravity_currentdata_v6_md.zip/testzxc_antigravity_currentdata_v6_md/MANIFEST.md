# Manifest — Antigravity Current-Data V6 Recovery Package

## Files
- `Goal.md`
- `00_MASTER_ANTIGRAVITY_ORDER.md`
- `01_FREEZE_MEDIUM_BASELINE_AND_TESTS.md`
- `02_HARD_EVENT_DATA_AUDIT.md`
- `03_HARD_EVENT_FILTER_V6.md`
- `04_EVIDENCE_PACK_REPAIR_V6.md`
- `05_RATIONALE_PROMPT_NEWS_USAGE_V6.md`
- `06_GENERATE_RATIONALES_1000X3_V6.md`
- `07_RATIONALE_DIVERSITY_AND_TEMPLATE_GATE.md`
- `08_INDEPENDENT_JUDGE_ENSEMBLE_V6.md`
- `09_JUDGE_CALIBRATION_AND_DEBIAS_TESTS.md`
- `10_FLOW_REWARD_V6_DECISION_TARGETS.md`
- `11_FLOW_EVAL_RAW_UTILITY_AND_PROXY.md`
- `12_ALIGNMENT_PAIRS_MIN_GAP_AND_DIVERSITY.md`
- `13_TRAIN_RWSFT_DPO_V6.md`
- `14_PREDICT_WITH_V6_ADAPTERS.md`
- `15_BACKTEST_TRACK_BASELINE_V6.md`
- `16_COUNTERFACTUAL_NEWS_EVIDENCE_V6.md`
- `17_BASELINES_SEP_POLICY_TECH_RULE.md`
- `18_ABLATIONS_V6.md`
- `19_STRICT_AAAI_STRONG_ACCEPT_GATE.md`
- `20_RUNBOOK_AND_NEGATIVE_RESULT_FALLBACK.md`
- `SOURCES_AND_REVIEW_BASIS.md`

## How to use
Give Antigravity one file at a time, starting from `Goal.md`, then `00_MASTER_ANTIGRAVITY_ORDER.md`, then `01` through `20`. Do not execute the whole package at once.

## Expected final result
Either `AAAI_strong_accept_ready=false` with an honest diagnostic package, or `AAAI_strong_accept_ready=true` only if every strict gate in `Goal.md` passes.
