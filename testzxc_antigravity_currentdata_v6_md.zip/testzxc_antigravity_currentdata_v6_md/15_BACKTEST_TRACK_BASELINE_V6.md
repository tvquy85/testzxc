# 15 — Daily Backtest V6 by Track and Baseline

> Scope: branch `currentdata-aaai-fix-v2`; current-data only; do not use SN2; do not expand full FNSPID. Execute one file at a time. Every step must write a status JSON and must stop on FAIL. Pipeline PASS is not a scientific claim.

## Goal
Evaluate decision utility without inflating Sharpe. Use daily portfolio returns and compare to Technical_Rule and technical-only/no-news baselines.

## Outputs
```text
outputs/metrics/15_v6_backtest_track_baseline.json
outputs/tables/15_v6_daily_returns.csv
outputs/tables/15_v6_track_breakdown.csv
outputs/status/15_BACKTEST_TRACK_BASELINE_V6.status.json
```

## Backtest rules
Aggregate date × ticker; use after-cost returns; include transaction cost, slippage, borrow cost; report by track; alpha claim blocked unless Sharpe >0 and days >=60 diagnostic.

## Test case
```python
from src.eval.backtest_daily_portfolio_v3 import compute_sharpe

def test_sharpe_zero_returns():
    assert compute_sharpe([0,0,0]) == 0
```

## Commands
```bash
python -m src.eval.backtest_daily_portfolio_v3 --predictions outputs/predictions/current_v6_dpo_predictions.parquet --output-daily outputs/tables/15_v6_daily_returns.csv --output-track outputs/tables/15_v6_track_breakdown.csv --metrics outputs/metrics/15_v6_backtest_track_baseline.json --status outputs/status/15_BACKTEST_TRACK_BASELINE_V6.status.json --cost-bps 5 --slippage-bps 2 --short-borrow-bps 1
python -m pytest -q tests/test_backtest_v6.py tests
```
