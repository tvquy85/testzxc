# 13 — Train RWSFT and DPO V6 Adapters

> Scope: branch `currentdata-aaai-fix-v2`; current-data only; do not use SN2; do not expand full FNSPID. Execute one file at a time. Every step must write a status JSON and must stop on FAIL. Pipeline PASS is not a scientific claim.

## Goal
Train real V6 adapters. Do not use V5 adapters for V6 prediction.

## Outputs
```text
outputs/models/qwen3_current_v6_rwsft_adapter/adapter_model.safetensors
outputs/models/qwen3_current_v6_dpo_adapter/adapter_model.safetensors
outputs/metrics/13_v6_alignment_training.json
outputs/status/13_TRAIN_RWSFT_DPO_V6.status.json
```

## Training config
Qwen3-4B-Instruct-2507, QLoRA/4-bit if supported, LoRA r=16, max_seq_len=2048, batch_size=1, grad_accum=16, fp16, max_steps=800 minimum.

## Test case
```python
from pathlib import Path

def test_v6_adapters_exist():
    assert Path('outputs/models/qwen3_current_v6_rwsft_adapter/adapter_model.safetensors').exists()
    assert Path('outputs/models/qwen3_current_v6_dpo_adapter/adapter_model.safetensors').exists()
```

## Commands
```bash
python -m src.alignment.train_rwsft_qlora --train-jsonl data/alignment/current_v6_rwsft.jsonl --config configs/local_paths.yaml --output-dir outputs/models/qwen3_current_v6_rwsft_adapter --max-steps 800 --status outputs/status/13A_TRAIN_RWSFT_V6.status.json
python -m src.alignment.train_dpo_qlora --train-jsonl data/alignment/current_v6_dpo_pairs.jsonl --config configs/local_paths.yaml --output-dir outputs/models/qwen3_current_v6_dpo_adapter --max-steps 800 --status outputs/status/13B_TRAIN_DPO_V6.status.json
python -m src.alignment.summarize_training_v6 --rwsft outputs/status/13A_TRAIN_RWSFT_V6.status.json --dpo outputs/status/13B_TRAIN_DPO_V6.status.json --metrics outputs/metrics/13_v6_alignment_training.json --status outputs/status/13_TRAIN_RWSFT_DPO_V6.status.json
python -m pytest -q tests/test_v6_adapter_files.py tests
```
