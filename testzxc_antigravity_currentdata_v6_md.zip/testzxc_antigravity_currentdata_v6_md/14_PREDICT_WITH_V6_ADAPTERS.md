# 14 — Predict with V6 Adapters on Held-Out Current Test Data

> Scope: branch `currentdata-aaai-fix-v2`; current-data only; do not use SN2; do not expand full FNSPID. Execute one file at a time. Every step must write a status JSON and must stop on FAIL. Pipeline PASS is not a scientific claim.

## Goal
Generate predictions with V6 adapters only. No older adapter may be used for V6 result.

## Outputs
```text
outputs/predictions/current_v6_rwsft_predictions.parquet
outputs/predictions/current_v6_dpo_predictions.parquet
outputs/metrics/14_v6_prediction_metrics.json
outputs/status/14_PREDICT_WITH_V6_ADAPTERS.status.json
```

## Requirements
Only `split == test`; at least 300 predictions; use forecast distribution to derive official action.

## Test case
```python
import pandas as pd
from pathlib import Path

def test_v6_prediction_files():
    p=Path('outputs/predictions/current_v6_dpo_predictions.parquet')
    assert p.exists()
    df=pd.read_parquet(p)
    assert len(df)>=300
    assert df['schema_ok'].mean()>=0.90
```

## Commands
```bash
python -m src.eval.generate_test_predictions_v2 --contexts data/processed/ticker_date_evidence_contexts_h1_v6_repaired.parquet --adapter outputs/models/qwen3_current_v6_dpo_adapter --config configs/local_paths.yaml --split test --output outputs/predictions/current_v6_dpo_predictions.parquet --samples review_samples/currentdata_v6/14_prediction_samples.jsonl --status outputs/status/14A_PREDICT_DPO_V6.status.json
python -m src.eval.generate_test_predictions_v2 --contexts data/processed/ticker_date_evidence_contexts_h1_v6_repaired.parquet --adapter outputs/models/qwen3_current_v6_rwsft_adapter --config configs/local_paths.yaml --split test --output outputs/predictions/current_v6_rwsft_predictions.parquet --status outputs/status/14B_PREDICT_RWSFT_V6.status.json
python -m src.eval.summarize_predictions_v6 --dpo outputs/predictions/current_v6_dpo_predictions.parquet --rwsft outputs/predictions/current_v6_rwsft_predictions.parquet --metrics outputs/metrics/14_v6_prediction_metrics.json --status outputs/status/14_PREDICT_WITH_V6_ADAPTERS.status.json
python -m pytest -q tests/test_v6_predictions.py tests
```
