# 19 — Strict AAAI Strong-Accept Gate V6

> Scope: branch `currentdata-aaai-fix-v2`; current-data only; do not use SN2; do not expand full FNSPID. Execute one file at a time. Every step must write a status JSON and must stop on FAIL. Pipeline PASS is not a scientific claim.

## Goal
Create the final V6 science gate. It must distinguish pipeline runnable, diagnostic contribution, current-data positive result, and AAAI strong-accept readiness.

## Outputs
```text
outputs/repro/currentdata_v6_strong_accept_gate.json
outputs/tables/19_v6_claim_matrix.csv
outputs/status/19_STRICT_AAAI_STRONG_ACCEPT_GATE.status.json
```

## Claim logic
Flow claim requires 2/3 core Flow wins. Alignment claim requires V6 beats Base/SFT. Trading alpha requires Sharpe >0 and enough days. Counterfactual claim requires pass/no-change/news gates. Baseline competitiveness requires beating Technical_Rule on Macro-F1 and MCC. AAAI strong accept requires all major claims plus comparable baselines and statistical tests.

## Test case
```python
from src.repro.currentdata_v6_strong_accept_gate import allow_flow_claim

def test_flow_claim_requires_two_wins():
    assert allow_flow_claim({'rank':True,'pair':True,'top_decile':False})
    assert not allow_flow_claim({'rank':False,'pair':True,'top_decile':False})
```

## Commands
```bash
python -m src.repro.currentdata_v6_strong_accept_gate --metrics-dir outputs/metrics --tables-dir outputs/tables --status-dir outputs/status --output outputs/repro/currentdata_v6_strong_accept_gate.json --claim-table outputs/tables/19_v6_claim_matrix.csv --status outputs/status/19_STRICT_AAAI_STRONG_ACCEPT_GATE.status.json
python -m pytest -q tests/test_strong_accept_gate_v6.py tests
```

## Acceptance
Gate may return `CLAIM_RESTRICTED`; it must never return strong-accept-ready unless all gates in `Goal.md` pass.
