# 17 — Comparable Baselines: Technical Rule, SEP-Style, Policy-Style Proxy

> Scope: branch `currentdata-aaai-fix-v2`; current-data only; do not use SN2; do not expand full FNSPID. Execute one file at a time. Every step must write a status JSON and must stop on FAIL. Pipeline PASS is not a scientific claim.

## Goal
Stop relying on reference-only PEN/SEP/Policy labels. Add comparable current-data baselines where feasible.

## Required baselines
Technical_Rule, Qwen_Base_NoAlign, Qwen_RWSFT_V6, Qwen_DPO_V6, SEP_Style_Summarize_Explain, Policy_Style_Scalar_Proxy, PEN_Reference_Only if no current-data PEN adapter is implemented.

## Outputs
```text
outputs/tables/17_v6_comparable_baselines.csv
outputs/metrics/17_v6_baseline_comparison.json
outputs/status/17_BASELINES_SEP_POLICY_TECH_RULE.status.json
```

## Test case
```python
import pandas as pd
from pathlib import Path

def test_baseline_table_has_required_methods():
    p=Path('outputs/tables/17_v6_comparable_baselines.csv')
    assert p.exists()
    methods=set(pd.read_csv(p)['method'])
    for name in ['Technical_Rule','Qwen_DPO_V6','Policy_Style_Scalar_Proxy']:
        assert name in methods
```

## Commands
```bash
python -m src.baselines.run_v6_comparable_baselines --contexts data/processed/ticker_date_evidence_contexts_h1_v6_repaired.parquet --dpo-predictions outputs/predictions/current_v6_dpo_predictions.parquet --rwsft-predictions outputs/predictions/current_v6_rwsft_predictions.parquet --output outputs/tables/17_v6_comparable_baselines.csv --metrics outputs/metrics/17_v6_baseline_comparison.json --status outputs/status/17_BASELINES_SEP_POLICY_TECH_RULE.status.json
python -m pytest -q tests/test_baseline_table_v6.py tests
```

## Acceptance
At least 6 baselines; reference-only baselines explicitly marked; forecast claim blocked unless V6 beats Technical_Rule on Macro-F1 and MCC.
