# Sources and Review Basis

## Repository sources used
- GitHub branch: `tvquy85/testzxc`, branch `currentdata-aaai-fix-v2`.
- Current medium report: `BaoCaoclean_v4_medium_21062026.md`.
- Master medium order: `clean_v4_medium_recovery_codex_md/00_MASTER_CLEAN_V4_MEDIUM_ORDER.md`.
- Science gate: `review_samples/clean_v4_medium_21062026/24_science_gate_report.json`.
- Code inspected: `src/repro/currentdata_clean_v4_medium_science_gate.py`, `src/reward/build_flow_dataset_v5.py`, `src/judges/independent_inferability_judge_v4.py`, `src/eval/backtest_daily_portfolio_v3.py`.

## External references
- AAAI-27 Main Technical Track Call: official criteria/reproducibility context. URL: https://aaai.org/conference/aaai/aaai-27/main-technical-track-call/
- FNSPID: 29.7M stock records, 15.7M aligned news records, 4,775 companies, 1999–2023. URL: https://github.com/Zdong104/FNSPID_Financial_News_Dataset
- SEP: Learning to Generate Explainable Stock Predictions using Self-Reflective Large Language Models. URL: https://arxiv.org/abs/2402.03659
- BenchStock: realistic stock forecasting evaluation and portfolio metrics. URL: https://openreview.net/pdf/de87306fbdbad74acf00a17ebc34a3e3688998e3.pdf
- Policy paper in local repo/upload: `Translate Policy to Language: Flow Matching Generated Rewards for LLM Explanations`; key ideas include hidden decision, proxy LLM logits, rectified flow reward, sentence-level dense reward, and PPO/LoRA.

## Design principles
Current-data before scale-up; status PASS is not claim allowed; no alpha without after-cost daily evidence; no flow claim unless Flow beats proxy; no multimodal claim unless news evidence contributes beyond technical baseline.
