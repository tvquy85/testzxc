# 12 — Build Alignment Dataset with Minimum Reward Gap and Semantic Diversity

> Scope: branch `currentdata-aaai-fix-v2`; current-data only; do not use SN2; do not expand full FNSPID. Execute one file at a time. Every step must write a status JSON and must stop on FAIL. Pipeline PASS is not a scientific claim.

## Goal
Avoid DPO pairs that differ only by tiny probability tweaks or templates.

## Outputs
```text
data/alignment/current_v6_rwsft.jsonl
data/alignment/current_v6_dpo_pairs.jsonl
outputs/metrics/12_v6_alignment_dataset.json
review_samples/currentdata_v6/12_dpo_pair_samples.jsonl
outputs/status/12_ALIGNMENT_PAIRS_MIN_GAP_AND_DIVERSITY.status.json
```

## Pair selection
`chosen = highest reward valid candidate`; `rejected = lower reward candidate with reward gap >= 0.05 and semantic distance >= 0.15`. Use proxy reward if Flow V6 fails.

## Test case
```python
from src.alignment.build_alignment_v6 import accept_pair

def test_accept_pair_gap_and_distance():
    assert accept_pair(0.70,0.60,0.20)
    assert not accept_pair(0.70,0.68,0.20)
    assert not accept_pair(0.70,0.60,0.05)
```

## Commands
```bash
python -m src.alignment.build_alignment_v6 --rationales data/rationales/parsed/current_v6_train_qwen3_1000x3.parquet --judge data/judges/current_v6_independent_judge_ensemble.parquet --flow-metrics outputs/metrics/11_v6_flow_vs_proxy_raw_utility.json --rwsft-output data/alignment/current_v6_rwsft.jsonl --dpo-output data/alignment/current_v6_dpo_pairs.jsonl --metrics outputs/metrics/12_v6_alignment_dataset.json --samples review_samples/currentdata_v6/12_dpo_pair_samples.jsonl --status outputs/status/12_ALIGNMENT_PAIRS_MIN_GAP_AND_DIVERSITY.status.json
python -m pytest -q tests/test_alignment_pair_selection_v6.py tests
```

## Acceptance
RWSFT >=1000, DPO >=300, mean gap >=0.035 diagnostic or >=0.05 preferred, semantic distance >=0.15.
