# 11 — Flow Evaluation against Proxy and Raw Realized Utility

> Scope: branch `currentdata-aaai-fix-v2`; current-data only; do not use SN2; do not expand full FNSPID. Execute one file at a time. Every step must write a status JSON and must stop on FAIL. Pipeline PASS is not a scientific claim.

## Goal
Evaluate Flow V6 fairly against proxy-average on held-out validation using both decision-distribution metrics and raw realized utility.

## Outputs
```text
outputs/models/flow_reward_v6_decision.pt
outputs/metrics/11_v6_flow_vs_proxy_raw_utility.json
outputs/status/11_FLOW_EVAL_RAW_UTILITY_AND_PROXY.status.json
```

## Metrics
`rank_correlation_with_true_label_probability`, `rank_correlation_with_raw_realized_utility`, `preference_pair_accuracy`, `kl_to_judge_distribution`, `top_decile_raw_utility`, `top_decile_target_probability`.

Flow improvement requires beating proxy on at least 2/3 core metrics: raw utility rank correlation, pair accuracy, top-decile raw utility.

## Test case
```python
from src.reward.evaluate_flow_v6 import metric_wins

def test_metric_wins_requires_two_of_three():
    assert metric_wins({'rank':True,'pair':False,'top_decile':True})
    assert not metric_wins({'rank':True,'pair':False,'top_decile':False})
```

## Commands
```bash
python -m src.reward.train_flow_reward_v6 --dataset data/reward/current_v6_flow_decision_dataset.pt --output outputs/models/flow_reward_v6_decision.pt --metrics outputs/metrics/11_v6_flow_train.json --status outputs/status/11_FLOW_TRAIN_V6.status.json
python -m src.reward.evaluate_flow_v6 --dataset data/reward/current_v6_flow_decision_dataset.pt --model outputs/models/flow_reward_v6_decision.pt --metrics outputs/metrics/11_v6_flow_vs_proxy_raw_utility.json --status outputs/status/11_FLOW_EVAL_RAW_UTILITY_AND_PROXY.status.json
python -m pytest -q tests/test_flow_eval_v6.py tests
```
