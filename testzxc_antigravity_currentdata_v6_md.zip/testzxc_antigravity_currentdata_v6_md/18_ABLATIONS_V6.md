# 18 — Ablation Suite V6

> Scope: branch `currentdata-aaai-fix-v2`; current-data only; do not use SN2; do not expand full FNSPID. Execute one file at a time. Every step must write a status JSON and must stop on FAIL. Pipeline PASS is not a scientific claim.

## Goal
Run ablations that test evidence grounding, news usage, flow reward, judge debias, and alignment.

## Required ablations
Full_V6, No_News_Evidence, Technical_Only, No_Technical_Tokens, No_Flow_Use_Proxy, No_Debias_Use_Normal_Order, No_Grounding_Filter, No_DPO_RWSFT_Only, Base_Qwen_NoAlign, Technical_Rule.

## Outputs
```text
outputs/tables/18_v6_ablation_results.csv
outputs/metrics/18_v6_ablation_summary.json
outputs/status/18_ABLATIONS_V6.status.json
```

## Test case
```python
import pandas as pd
from pathlib import Path

def test_no_not_run_in_ablation():
    p=Path('outputs/tables/18_v6_ablation_results.csv')
    assert p.exists()
    df=pd.read_csv(p).astype(str)
    assert 'NOT_RUN' not in set(df.values.ravel())
```

## Commands
```bash
python -m src.eval.run_v6_ablation_suite --contexts data/processed/ticker_date_evidence_contexts_h1_v6_repaired.parquet --predictions outputs/predictions/current_v6_dpo_predictions.parquet --baselines outputs/tables/17_v6_comparable_baselines.csv --output outputs/tables/18_v6_ablation_results.csv --metrics outputs/metrics/18_v6_ablation_summary.json --status outputs/status/18_ABLATIONS_V6.status.json
python -m pytest -q tests/test_ablation_v6.py tests
```
