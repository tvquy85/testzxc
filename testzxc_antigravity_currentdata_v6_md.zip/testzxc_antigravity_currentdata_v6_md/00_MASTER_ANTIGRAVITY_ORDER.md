# 00 — Master Antigravity Execution Order for Current-Data V6

> Scope: branch `currentdata-aaai-fix-v2`; current-data only; do not use SN2; do not expand full FNSPID. Execute one file at a time. Every step must write a status JSON and must stop on FAIL. Pipeline PASS is not a scientific claim.

## Execute in this order

1. `01_FREEZE_MEDIUM_BASELINE_AND_TESTS.md`
2. `02_HARD_EVENT_DATA_AUDIT.md`
3. `03_HARD_EVENT_FILTER_V6.md`
4. `04_EVIDENCE_PACK_REPAIR_V6.md`
5. `05_RATIONALE_PROMPT_NEWS_USAGE_V6.md`
6. `06_GENERATE_RATIONALES_1000X3_V6.md`
7. `07_RATIONALE_DIVERSITY_AND_TEMPLATE_GATE.md`
8. `08_INDEPENDENT_JUDGE_ENSEMBLE_V6.md`
9. `09_JUDGE_CALIBRATION_AND_DEBIAS_TESTS.md`
10. `10_FLOW_REWARD_V6_DECISION_TARGETS.md`
11. `11_FLOW_EVAL_RAW_UTILITY_AND_PROXY.md`
12. `12_ALIGNMENT_PAIRS_MIN_GAP_AND_DIVERSITY.md`
13. `13_TRAIN_RWSFT_DPO_V6.md`
14. `14_PREDICT_WITH_V6_ADAPTERS.md`
15. `15_BACKTEST_TRACK_BASELINE_V6.md`
16. `16_COUNTERFACTUAL_NEWS_EVIDENCE_V6.md`
17. `17_BASELINES_SEP_POLICY_TECH_RULE.md`
18. `18_ABLATIONS_V6.md`
19. `19_STRICT_AAAI_STRONG_ACCEPT_GATE.md`
20. `20_RUNBOOK_AND_NEGATIVE_RESULT_FALLBACK.md`

## Intent
This plan addresses current Clean V4 Medium failures: Flow does not beat proxy enough, alpha remains negative, counterfactual faithfulness is blocked, rationales are template-heavy, judge signal is near random, Technical_Rule beats aligned LLM, and PEN/SEP/Policy are not comparable baselines yet.

## Test case
Create `tests/test_v6_file_order.py`:
```python
from pathlib import Path

def test_v6_goal_and_master_exist():
    assert Path('Goal.md').exists() or Path('testzxc_antigravity_currentdata_v6_md/Goal.md').exists()
```
Run `python -m pytest -q tests/test_v6_file_order.py`.
