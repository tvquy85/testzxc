# 08 — Independent Judge Ensemble V6

> Scope: branch `currentdata-aaai-fix-v2`; current-data only; do not use SN2; do not expand full FNSPID. Execute one file at a time. Every step must write a status JSON and must stop on FAIL. Pipeline PASS is not a scientific claim.

## Goal
Strengthen judge signal. Use at least normal, reversed, and stable-random label orders; optionally add a second local judge.

## Outputs
```text
data/judges/current_v6_independent_judge_ensemble.parquet
outputs/metrics/08_v6_judge_ensemble.json
outputs/status/08_INDEPENDENT_JUDGE_ENSEMBLE_V6.status.json
```

## Required columns
`p_strong_down`, `p_mild_down`, `p_neutral`, `p_mild_up`, `p_strong_up`, `true_label_probability_ensemble`, `argmax_consistency_ensemble`, `label_order_kl_mean`, `judge_disagreement_entropy`, `judge_schema_ok`.

## Test case
```python
from src.judges.judge_ensemble_v6 import average_distributions

def test_average_distributions_sums_to_one():
    out=average_distributions([{'a':0.2,'b':0.8},{'a':0.4,'b':0.6}])
    assert abs(sum(out.values())-1.0)<1e-8
    assert out['a']==0.3
```

## Commands
```bash
python -m src.judges.judge_ensemble_v6 --rationales data/rationales/parsed/current_v6_train_qwen3_1000x3.parquet --contexts data/processed/ticker_date_evidence_contexts_h1_v6_repaired.parquet --config configs/local_paths.yaml --model-key judge_llm --label-order-variants normal,reversed,stable_random --batch-size 4 --max-new-tokens 160 --temperature 0.0 --output data/judges/current_v6_independent_judge_ensemble.parquet --metrics outputs/metrics/08_v6_judge_ensemble.json --samples review_samples/currentdata_v6/08_judge_ensemble_samples.jsonl --status outputs/status/08_INDEPENDENT_JUDGE_ENSEMBLE_V6.status.json
python -m pytest -q tests/test_judge_ensemble_v6.py tests
```

## Acceptance
Schema >=0.95, true-label probability >0.22 minimum, consistency >=0.75.
