# 10 — Flow Reward V6 with Decision-Distribution Targets

> Scope: branch `currentdata-aaai-fix-v2`; current-data only; do not use SN2; do not expand full FNSPID. Execute one file at a time. Every step must write a status JSON and must stop on FAIL. Pipeline PASS is not a scientific claim.

## Goal
Build Flow primary target from independent judge decision distributions, closer to Policy-style proxy logits/distributions. Keep utility/grounding as auxiliary columns.

## Outputs
```text
data/reward/current_v6_flow_decision_dataset.pt
outputs/metrics/10_v6_flow_dataset_decision_targets.json
outputs/status/10_FLOW_REWARD_V6_DECISION_TARGETS.status.json
```

## Target design
Primary target dimension = 5: `[p_strong_down, p_mild_down, p_neutral, p_mild_up, p_strong_up]`. Save auxiliary `news_grounding_score`, `technical_grounding_score`, `raw_realized_utility`, `abnormal_return_h1`, `evidence_quality_weight`.

## Test case
```python
import torch
from pathlib import Path

def test_flow_decision_dataset_shape():
    p=Path('data/reward/current_v6_flow_decision_dataset.pt')
    assert p.exists()
    data=torch.load(p,map_location='cpu')
    assert data['target'].shape[1]==5
    assert data['cond'].shape[0]==data['target'].shape[0]
    assert set(data['split']).issuperset({'train','val'})
```

## Commands
```bash
python -m src.reward.build_flow_decision_dataset_v6 --rationales data/rationales/parsed/current_v6_train_qwen3_1000x3.parquet --judge data/judges/current_v6_independent_judge_ensemble.parquet --contexts data/processed/ticker_date_evidence_contexts_h1_v6_repaired.parquet --output data/reward/current_v6_flow_decision_dataset.pt --metrics outputs/metrics/10_v6_flow_dataset_decision_targets.json --status outputs/status/10_FLOW_REWARD_V6_DECISION_TARGETS.status.json
python -m pytest -q tests/test_flow_decision_dataset_v6.py tests
```

## Acceptance
Rows >=2700, target dim=5, train/val split exists, target rows sum to one, condition dim >=128.
