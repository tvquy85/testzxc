# 20 — Runbook and Negative-Result Fallback

> Scope: branch `currentdata-aaai-fix-v2`; current-data only; do not use SN2; do not expand full FNSPID. Execute one file at a time. Every step must write a status JSON and must stop on FAIL. Pipeline PASS is not a scientific claim.

## Goal
Create a final runbook. If V6 cannot support strong claims, produce an honest negative-result package.

## Outputs
```text
RUNBOOK_currentdata_v6.md
paper/stories/currentdata_v6_negative_result_summary.md
outputs/status/20_RUNBOOK_AND_NEGATIVE_RESULT_FALLBACK.status.json
```

## Required runbook sections
Environment/model paths; current-data scope; exact command order; artifacts by step; claim matrix; known failures; table reproduction; what can/cannot be claimed; next full-scale path.

## Negative-result fallback text
```text
The current-data V6 pipeline improves reproducibility and evidence grounding, but does not yet establish strong forecast or trading improvement. Flow reward and alignment should be interpreted as diagnostic experiments until they beat proxy and technical baselines under strict validation.
```

## Test case
```python
from pathlib import Path

def test_runbook_mentions_claim_restriction():
    p=Path('RUNBOOK_currentdata_v6.md')
    assert p.exists()
    text=p.read_text(encoding='utf-8').lower()
    assert 'claim' in text and ('restricted' in text or 'blocked' in text)
```

## Commands
```bash
python -m src.repro.write_v6_runbook --gate outputs/repro/currentdata_v6_strong_accept_gate.json --claim-table outputs/tables/19_v6_claim_matrix.csv --output RUNBOOK_currentdata_v6.md --negative-summary paper/stories/currentdata_v6_negative_result_summary.md --status outputs/status/20_RUNBOOK_AND_NEGATIVE_RESULT_FALLBACK.status.json
python -m pytest -q tests/test_runbook_v6.py tests
```
