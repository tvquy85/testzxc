# 09 — Judge Calibration and Debias Tests

> Scope: branch `currentdata-aaai-fix-v2`; current-data only; do not use SN2; do not expand full FNSPID. Execute one file at a time. Every step must write a status JSON and must stop on FAIL. Pipeline PASS is not a scientific claim.

## Goal
Quantify whether judge probabilities are meaningful and label-order robust.

## Outputs
```text
outputs/metrics/09_v6_judge_calibration.json
outputs/tables/09_v6_judge_reliability_bins.csv
outputs/status/09_JUDGE_CALIBRATION_AND_DEBIAS_TESTS.status.json
```

## Metrics
Brier score, ECE, NLL if valid, true-label prob by track, argmax consistency by track, label-order KL by track.

## Test case
```python
from src.judges.judge_calibration_v6 import expected_calibration_error

def test_ece_perfect():
    ece=expected_calibration_error([0.9,0.8],[1,1],n_bins=2)
    assert 0 <= ece <= 0.2
```

## Commands
```bash
python -m src.judges.judge_calibration_v6 --input data/judges/current_v6_independent_judge_ensemble.parquet --metrics outputs/metrics/09_v6_judge_calibration.json --bins outputs/tables/09_v6_judge_reliability_bins.csv --status outputs/status/09_JUDGE_CALIBRATION_AND_DEBIAS_TESTS.status.json
python -m pytest -q tests/test_judge_calibration_v6.py tests
```

## Acceptance
All probabilities finite and sum to one. If true-label probability <=0.20, stop Flow/DPO and fix judge or data.
