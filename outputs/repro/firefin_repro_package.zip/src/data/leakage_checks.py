from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from src.utils.artifacts import write_json, write_manifest, write_status


STEP = "04_LEAKAGE_GUARDS_AND_UNIT_TESTS"
PROMPT_LEAK_PATTERNS = [
    r"\brealized\s+(return|label)\b",
    r"\bfuture\s+(close|price|return|label)\b",
    r"\bshares\s+(rose|fell|surged|plunged)\s+after\b",
    r"\bstock\s+(rises|falls|rose|fell)\s+after\b",
]


def _to_timestamp(series):
    import pandas as pd

    return pd.to_datetime(series).dt.tz_localize(None)


def check_timestamp_rule(samples) -> list[dict[str, Any]]:
    leaks: list[dict[str, Any]] = []
    if {"timestamp_utc", "event_date"}.issubset(samples.columns):
        news_time = _to_timestamp(samples["timestamp_utc"])
        decision = _to_timestamp(samples["event_date"])
        mask = news_time.dt.normalize() > decision
        for _, row in samples.loc[mask].head(20).iterrows():
            leaks.append({"type": "news_after_decision", "sample_id": row.get("sample_id")})
    if {"window_end_date", "event_date"}.issubset(samples.columns):
        window_end = _to_timestamp(samples["window_end_date"])
        decision = _to_timestamp(samples["event_date"])
        mask = window_end > decision
        for _, row in samples.loc[mask].head(20).iterrows():
            leaks.append({"type": "feature_window_after_decision", "sample_id": row.get("sample_id")})
    return leaks


def check_split_rule(splits) -> list[dict[str, Any]]:
    leaks: list[dict[str, Any]] = []
    if "sample_id" not in splits.columns or "split" not in splits.columns:
        return [{"type": "split_file_missing_columns"}]
    dupes = splits[splits["sample_id"].duplicated(keep=False)]
    for _, row in dupes.head(20).iterrows():
        leaks.append({"type": "duplicate_split_membership", "sample_id": row["sample_id"]})
    illegal = splits[~splits["split"].isin(["train", "val", "test"])]
    for _, row in illegal.head(20).iterrows():
        leaks.append({"type": "illegal_split_value", "sample_id": row["sample_id"], "split": row["split"]})
    return leaks


def check_prompt_leakage(prompt_root: str = "prompts") -> list[dict[str, Any]]:
    leaks: list[dict[str, Any]] = []
    root = Path(prompt_root)
    if not root.exists():
        return leaks
    patterns = [(p, re.compile(p, re.IGNORECASE)) for p in PROMPT_LEAK_PATTERNS]
    for path in root.rglob("*.txt"):
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        for pattern_text, pattern in patterns:
            matches = []
            for line in lines:
                lowered = line.lower()
                if any(guard in lowered for guard in ["do not", "don't", "never", "without"]):
                    continue
                matches.extend(pattern.finditer(line))
            if matches:
                leaks.append({"type": "prompt_leakage_pattern", "path": str(path), "pattern": pattern_text, "count": len(matches)})
    return leaks


def iter_jsonl(path: Path):
    with open(path, encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            if not line.strip():
                continue
            try:
                yield line_no, json.loads(line)
            except Exception as exc:
                yield line_no, {"__parse_error__": str(exc)}


def check_alignment_outputs(splits, paths: list[str]) -> list[dict[str, Any]]:
    leaks: list[dict[str, Any]] = []
    if "sample_id" not in splits.columns or "split" not in splits.columns:
        return leaks
    split_map = splits.set_index("sample_id")["split"].to_dict()
    for path_text in paths:
        path = Path(path_text)
        if not path.exists():
            continue
        if path.suffix == ".jsonl":
            for line_no, record in iter_jsonl(path):
                sample_id = record.get("sample_id")
                if sample_id is None and isinstance(record.get("chosen"), dict):
                    sample_id = record["chosen"].get("sample_id")
                if sample_id is None:
                    leaks.append({"type": "alignment_missing_sample_id", "path": str(path), "line": line_no})
                    continue
                split = split_map.get(sample_id)
                if split != "train":
                    leaks.append({"type": "alignment_non_train_sample", "path": str(path), "line": line_no, "sample_id": sample_id, "split": split})
                    if len(leaks) >= 50:
                        return leaks
    return leaks


def run_checks(samples_path: str, splits_path: str, prompt_root: str, alignment_paths: list[str], legacy_alignment_paths: list[str] | None = None) -> dict[str, Any]:
    import pandas as pd

    samples = pd.read_parquet(samples_path)
    splits = pd.read_parquet(splits_path)
    leak_examples: list[dict[str, Any]] = []
    leak_examples.extend(check_timestamp_rule(samples))
    leak_examples.extend(check_split_rule(splits))
    leak_examples.extend(check_prompt_leakage(prompt_root))
    leak_examples.extend(check_alignment_outputs(splits, alignment_paths))
    legacy_risks = check_alignment_outputs(splits, legacy_alignment_paths or [])
    return {
        "num_leaks": len(leak_examples),
        "leak_examples": leak_examples[:100],
        "legacy_alignment_risk_count": len(legacy_risks),
        "legacy_alignment_risk_examples": legacy_risks[:20],
        "passed": len(leak_examples) == 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--samples", default="data/labels/aligned_samples_h1.parquet")
    parser.add_argument("--splits", default="data/processed/split_membership.parquet")
    parser.add_argument("--prompt-root", default="prompts")
    parser.add_argument("--alignment-path", action="append", default=None)
    parser.add_argument("--legacy-alignment-path", action="append", default=["data/rationales/rwsft_train_h1.jsonl", "data/rationales/preference_pairs_h1.jsonl"])
    parser.add_argument("--output", default="outputs/audit/leakage_report.json")
    parser.add_argument("--status", default=f"outputs/status/{STEP}.status.json")
    parser.add_argument("--manifest", default=f"outputs/manifests/{STEP}.manifest.json")
    args = parser.parse_args()

    alignment_paths = args.alignment_path or ["data/alignment/rwsft_train_v2.jsonl", "data/alignment/dpo_pairs_train_v2.jsonl"]
    report = run_checks(args.samples, args.splits, args.prompt_root, alignment_paths, args.legacy_alignment_path)
    write_json(args.output, report)
    write_manifest(args.manifest, [args.output], STEP)
    failures = [] if report["passed"] else [f"hard leakage checks failed: {report['num_leaks']} leaks"]
    status = "PASS" if report["passed"] else "FAIL"
    write_status(
        args.status,
        STEP,
        status,
        inputs_checked=[args.samples, args.splits, args.prompt_root, *alignment_paths, *args.legacy_alignment_path],
        outputs_created=[args.output, args.manifest, args.status],
        metrics={
            "num_leaks": report["num_leaks"],
            "legacy_alignment_risk_count": report["legacy_alignment_risk_count"],
            "passed": report["passed"],
        },
        failures=failures,
        next_step_allowed=status == "PASS",
    )
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
