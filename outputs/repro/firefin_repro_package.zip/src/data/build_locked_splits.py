from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from src.utils.artifacts import write_json, write_manifest, write_status


STEP = "03_DATA_SCALE_AND_SPLIT_LOCK"


def assign_split(date):
    import pandas as pd

    d = pd.Timestamp(date).tz_localize(None)
    if d <= pd.Timestamp("2021-12-31"):
        return "train"
    if pd.Timestamp("2022-01-01") <= d <= pd.Timestamp("2022-12-31"):
        return "val"
    return "test"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="data/labels/aligned_samples_h1.parquet")
    parser.add_argument("--output", default="data/processed/split_membership.parquet")
    parser.add_argument("--manifest-output", default="outputs/manifests/split_manifest.json")
    parser.add_argument("--status", default=f"outputs/status/{STEP}.status.json")
    parser.add_argument("--task-manifest", default=f"outputs/manifests/{STEP}.manifest.json")
    args = parser.parse_args()

    import pandas as pd

    failures: list[str] = []
    df = pd.read_parquet(args.input)
    date_col = "event_date" if "event_date" in df.columns else "timestamp_utc"
    required = {"sample_id", date_col}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    out = df[["sample_id", date_col]].copy()
    out[date_col] = pd.to_datetime(out[date_col]).dt.tz_localize(None)
    out["split"] = out[date_col].apply(assign_split)
    out = out.rename(columns={date_col: "split_date"})
    duplicated = int(out["sample_id"].duplicated().sum())
    if duplicated:
        failures.append(f"duplicate sample_id rows found: {duplicated}")
    ranges = {}
    for split, group in out.groupby("split"):
        ranges[split] = {
            "rows": int(len(group)),
            "date_min": str(group["split_date"].min().date()) if len(group) else None,
            "date_max": str(group["split_date"].max().date()) if len(group) else None,
        }
    overlap_ok = True
    if "train" in ranges and ranges["train"]["date_max"] and ranges["train"]["date_max"] > "2021-12-31":
        overlap_ok = False
    if "val" in ranges and ranges["val"]["date_min"] and ranges["val"]["date_min"] < "2022-01-01":
        overlap_ok = False
    if not overlap_ok:
        failures.append("date ranges overlap fixed chronological boundaries")

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    out.to_parquet(args.output, index=False)
    split_manifest = {
        "split_policy": {
            "train": "date <= 2021-12-31",
            "val": "2022-01-01 <= date <= 2022-12-31",
            "test": "date >= 2023-01-01 or remaining future dates",
        },
        "input": args.input,
        "output": args.output,
        "ranges": ranges,
        "sample_id_unique": duplicated == 0,
    }
    write_json(args.manifest_output, split_manifest)
    write_manifest(args.task_manifest, [args.output, args.manifest_output], STEP)
    status = "PASS" if not failures else "FAIL"
    write_status(
        args.status,
        STEP,
        status,
        inputs_checked=[args.input],
        outputs_created=[args.output, args.manifest_output, args.task_manifest, args.status],
        metrics={"rows": int(len(out)), "split_counts": out["split"].value_counts().to_dict(), "ranges": ranges},
        failures=failures,
        next_step_allowed=status == "PASS",
    )
    print(json.dumps(split_manifest, indent=2, ensure_ascii=False))
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())

