from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from src.llm.generate_rationales import normalize_direction
from src.utils.artifacts import write_json, write_manifest, write_status


STEP = "STAGE1_TRAIN_CONFLICT_SUBSET"
POSITIVE_WORDS = {
    "beat",
    "beats",
    "raise",
    "raises",
    "raised",
    "upgrade",
    "upgraded",
    "growth",
    "profit",
    "surge",
    "strong",
    "bullish",
    "partnership",
    "approval",
    "launch",
}
NEGATIVE_WORDS = {
    "miss",
    "misses",
    "cut",
    "cuts",
    "downgrade",
    "downgraded",
    "loss",
    "probe",
    "lawsuit",
    "weak",
    "bearish",
    "decline",
    "falls",
    "plunge",
    "warning",
}
EVENT_RE = re.compile(r"\b(earnings?|guidance|outlook|forecast|revenue|profit|loss|dividend|merger|acquisition|fda|approval)\b", re.IGNORECASE)


def _tokens(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    if isinstance(value, str) and value.strip():
        try:
            data = json.loads(value)
            return [item for item in data if isinstance(item, dict)] if isinstance(data, list) else []
        except Exception:
            return []
    return []


def text_polarity(headline: Any, body: Any) -> int:
    text = f"{headline or ''} {body or ''}".lower()
    words = re.findall(r"[a-z]+", text)
    pos = sum(1 for word in words if word in POSITIVE_WORDS)
    neg = sum(1 for word in words if word in NEGATIVE_WORDS)
    return 1 if pos > neg else -1 if neg > pos else 0


def technical_direction_stats(tokens_json: Any) -> tuple[int, int, bool]:
    pos = 0
    neg = 0
    for item in _tokens(tokens_json):
        direction = normalize_direction(item.get("direction_prior", item.get("direction", item.get("token"))))
        if direction == "positive":
            pos += 1
        elif direction == "negative":
            neg += 1
    return pos, neg, pos > 0 and neg > 0


def score_conflict_rows(df):
    scores = []
    flags = []
    for _, row in df.iterrows():
        pos_count, neg_count, mixed_tech = technical_direction_stats(row.get("technical_event_tokens_json"))
        news_pol = text_polarity(row.get("headline"), row.get("body"))
        tech_pol = 1 if pos_count > neg_count else -1 if neg_count > pos_count else 0
        news_tech_conflict = news_pol != 0 and tech_pol != 0 and news_pol != tech_pol
        strong_label = row.get("label_5") in {"strong_down", "strong_up"}
        high_vol = row.get("regime_label") == "high_vol"
        event_keyword = bool(EVENT_RE.search(f"{row.get('headline') or ''} {row.get('body') or ''}"))
        score = (
            5 * int(news_tech_conflict)
            + 4 * int(mixed_tech)
            + 3 * int(strong_label)
            + 2 * int(high_vol)
            + int(event_keyword)
        )
        scores.append(score)
        flags.append(
            {
                "news_tech_conflict": news_tech_conflict,
                "mixed_technical_direction": mixed_tech,
                "strong_label": strong_label,
                "high_vol_regime": high_vol,
                "event_keyword": event_keyword,
                "news_polarity": news_pol,
                "technical_positive_count": pos_count,
                "technical_negative_count": neg_count,
            }
        )
    return scores, flags


def build_subset(samples, splits, tokens, limit: int, seed: int):
    import pandas as pd

    df = samples.drop(columns=["split"], errors="ignore").merge(
        splits[["sample_id", "split"]],
        on="sample_id",
        how="inner",
        validate="one_to_one",
    )
    df = df[df["split"] == "train"].copy()
    token_cols = [c for c in ["sample_id", "technical_event_tokens_json", "regime_label"] if c in tokens.columns]
    if token_cols:
        df = df.merge(tokens[token_cols], on="sample_id", how="left", suffixes=("", "_token"))
        if "regime_label_token" in df.columns:
            df["regime_label"] = df["regime_label"].fillna(df["regime_label_token"]) if "regime_label" in df.columns else df["regime_label_token"]
    scores, flags = score_conflict_rows(df)
    df["conflict_score"] = scores
    for key in flags[0].keys() if flags else []:
        df[key] = [flag[key] for flag in flags]
    hard = df[df["conflict_score"] > 0].copy()
    if len(hard) < limit:
        filler = df[df["conflict_score"] == 0].sample(n=min(limit - len(hard), int((df["conflict_score"] == 0).sum())), random_state=seed)
        hard = pd.concat([hard, filler], ignore_index=True)
    hard = hard.sort_values(["conflict_score", "event_date", "sample_id"], ascending=[False, True, True]).head(limit).copy()
    return hard


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--samples", default="data/labels/labels_h1_abnormal.parquet")
    parser.add_argument("--splits", default="data/processed/split_membership.parquet")
    parser.add_argument("--tokens", default="data/indicators/technical_event_tokens_h1_v2.parquet")
    parser.add_argument("--limit", type=int, default=2500)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", default="data/splits/train_conflict_subset_h1.parquet")
    parser.add_argument("--summary", default="outputs/metrics/train_conflict_subset_h1_summary.json")
    parser.add_argument("--status", default=f"outputs/status/{STEP}.status.json")
    parser.add_argument("--manifest", default=f"outputs/manifests/{STEP}.manifest.json")
    args = parser.parse_args()

    import pandas as pd

    failures: list[str] = []
    samples = pd.read_parquet(args.samples)
    splits = pd.read_parquet(args.splits)
    tokens = pd.read_parquet(args.tokens) if Path(args.tokens).exists() else pd.DataFrame()
    subset = build_subset(samples, splits, tokens, args.limit, args.seed)
    if subset.empty:
        failures.append("conflict subset is empty")
    if "split" not in subset.columns or set(subset["split"].dropna()) != {"train"}:
        failures.append("conflict subset must contain train rows only")
    if len(subset) < args.limit:
        failures.append(f"conflict subset has {len(subset)} rows, expected {args.limit}")
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    subset.to_parquet(args.output, index=False)
    summary = {
        "rows": int(len(subset)),
        "limit": args.limit,
        "split_counts": subset["split"].value_counts().to_dict() if "split" in subset else {},
        "conflict_score_counts": subset["conflict_score"].value_counts().sort_index().to_dict() if "conflict_score" in subset else {},
        "flag_counts": {
            key: int(subset[key].sum())
            for key in ["news_tech_conflict", "mixed_technical_direction", "strong_label", "high_vol_regime", "event_keyword"]
            if key in subset
        },
    }
    write_json(args.summary, summary)
    write_manifest(args.manifest, [args.output, args.summary], STEP)
    status = "PASS" if not failures else "FAIL"
    write_status(
        args.status,
        STEP,
        status,
        inputs_checked=[args.samples, args.splits, args.tokens],
        outputs_created=[args.output, args.summary, args.manifest, args.status],
        metrics=summary,
        failures=failures,
        next_step_allowed=status == "PASS",
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
