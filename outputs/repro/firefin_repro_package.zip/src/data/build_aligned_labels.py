import os
import json
import argparse
import pandas as pd
import numpy as np

def label_return(abnormal_ret):
    if pd.isna(abnormal_ret):
        return "Unknown"
    if abnormal_ret <= -0.03:
        return "Strong Down"
    elif -0.03 < abnormal_ret <= -0.0075:
        return "Mild Down"
    elif -0.0075 < abnormal_ret < 0.0075:
        return "Neutral"
    elif 0.0075 <= abnormal_ret < 0.03:
        return "Mild Up"
    else:
        return "Strong Up"

def check_leakage(text):
    if not isinstance(text, str):
        return False
    text = text.lower()
    leakage_phrases = [
        "shares surged", "shares plunged", "stock rises after", 
        "stock falls after", "trading higher after", "trading lower after",
        "shares jumped", "shares sank"
    ]
    return any(phrase in text for phrase in leakage_phrases)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--news", type=str, default="data/processed/news_mvp.parquet")
    parser.add_argument("--prices", type=str, default="data/processed/prices_mvp.parquet")
    parser.add_argument("--horizon", type=int, default=1)
    parser.add_argument("--output", type=str, default="data/labels/aligned_samples_h1.parquet")
    args = parser.parse_args()

    print("Loading data...")
    news = pd.read_parquet(args.news)
    prices = pd.read_parquet(args.prices)

    prices["date"] = pd.to_datetime(prices["date"]).dt.tz_localize(None)
    news["timestamp_utc"] = pd.to_datetime(news["timestamp_utc"])
    
    # 1. Trading dates mapping
    unique_dates = np.sort(prices["date"].unique())
    trade_dates_df = pd.DataFrame({"trade_date": unique_dates})
    
    # 2. Determine Event Date
    # Conservative rule: event_date = next trading day after news timestamp date
    news["news_date_naive"] = news["timestamp_utc"].dt.tz_localize(None).dt.floor('d') + pd.Timedelta(days=1)
    
    # Align to next available trading date
    print("Aligning event dates...")
    news = news.sort_values("news_date_naive")
    
    # merge_asof requires sorted keys
    news = pd.merge_asof(news, trade_dates_df, left_on="news_date_naive", right_on="trade_date", direction="forward")
    news["event_date"] = news["trade_date"]
    news = news.dropna(subset=["event_date"])

    # 3. Build Prior Window & Compute Future Return
    print("Computing returns...")
    # Precompute prices metrics
    prices = prices.sort_values(["ticker", "date"])
    prices["adj_close_next"] = prices.groupby("ticker")["adj_close"].shift(-args.horizon)
    prices["stock_return_h1"] = (prices["adj_close_next"] / prices["adj_close"]) - 1
    
    # Prior window (60 days) - just need start and end date
    prices["window_end_date"] = prices.groupby("ticker")["date"].shift(1)
    prices["window_start_date"] = prices.groupby("ticker")["date"].shift(60)

    # Compute market return
    market_returns = prices.groupby("date")["stock_return_h1"].mean().reset_index()
    market_returns.rename(columns={"stock_return_h1": "market_return_h1"}, inplace=True)
    prices = pd.merge(prices, market_returns, on="date", how="left")
    prices["abnormal_return_h1"] = prices["stock_return_h1"] - prices["market_return_h1"]

    # 4. Merge News and Prices on (ticker, event_date)
    print("Merging data...")
    aligned = pd.merge(news, prices[["ticker", "date", "stock_return_h1", "market_return_h1", "abnormal_return_h1", "window_start_date", "window_end_date"]], 
                       left_on=["ticker", "event_date"], right_on=["ticker", "date"], how="inner")
                       
    aligned = aligned.dropna(subset=["window_start_date", "abnormal_return_h1"])
    aligned["horizon"] = args.horizon
    aligned["sample_id"] = [f"s_{i}" for i in range(len(aligned))]

    # 5. Build 5-class label
    aligned["label_5"] = aligned["abnormal_return_h1"].apply(label_return)

    # 6. Leakage Flags
    print("Computing leakage flags...")
    aligned["leakage_phrase_flag"] = aligned["headline"].apply(check_leakage) | aligned["body"].apply(check_leakage)
    aligned["post_market_uncertain_flag"] = True # We used conservative rule for all, so we can set this.

    cols = ["sample_id", "ticker", "timestamp_utc", "event_date", "horizon", "headline", "body", 
            "stock_return_h1", "market_return_h1", "abnormal_return_h1", "label_5", 
            "window_start_date", "window_end_date", "leakage_phrase_flag", "post_market_uncertain_flag"]
            
    aligned = aligned[cols]

    # Save outputs
    print("Saving outputs...")
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    aligned.to_parquet(args.output, index=False)
    
    dist_path = "data/labels/label_distribution_h1.csv"
    dist = aligned["label_5"].value_counts().reset_index()
    dist.columns = ["label_5", "count"]
    dist.to_csv(dist_path, index=False)

    status = {
        "step": "04_PRICE_NEWS_ALIGNMENT_AND_LABELS",
        "status": "PASS" if len(aligned) > 0 else "FAIL",
        "aligned_rows": len(aligned),
        "label_distribution": dist.set_index("label_5")["count"].to_dict(),
        "leakage_flag_rate": float(aligned["leakage_phrase_flag"].mean()),
        "date_min": str(aligned["event_date"].min())[:10] if not aligned.empty else None,
        "date_max": str(aligned["event_date"].max())[:10] if not aligned.empty else None,
        "notes": "Used conservative next-trading-day rule for all event dates."
    }

    with open("outputs/status/04_PRICE_NEWS_ALIGNMENT_AND_LABELS.status.json", "w") as f:
        json.dump(status, f, indent=2)

    print(json.dumps(status, indent=2))

if __name__ == "__main__":
    main()
