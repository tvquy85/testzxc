import os
import json
import zipfile
import pandas as pd
import argparse

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=str, default="data/raw/fnspid_file_manifest.csv")
    parser.add_argument("--out", type=str, default="outputs/status/fnspid_schema_report.json")
    args = parser.parse_args()

    manifest = pd.read_csv(args.manifest)

    report = {"news_schema": {}, "price_schema": {}}

    news_file = manifest[manifest["guessed_role"] == "news"].iloc[0]["path"]
    price_file = manifest[manifest["guessed_role"] == "price"].iloc[0]["path"]

    # Infer News
    try:
        # Read the preview if the original is too big
        safe_filename = os.path.basename(news_file).replace(".", "_")
        preview_path = f"data/raw/previews/{safe_filename}.head100.csv"
        news_df = pd.read_csv(preview_path)
        report["news_schema"]["original_columns"] = news_df.columns.tolist()
        
        mapping = {}
        cols = news_df.columns.tolist()
        if "Article_title" in cols: mapping["Article_title"] = "headline"
        if "Stock_symbol" in cols: mapping["Stock_symbol"] = "ticker"
        if "Date" in cols: mapping["Date"] = "timestamp_utc"
        if "Article" in cols: mapping["Article"] = "body"
        if "Publisher" in cols: mapping["Publisher"] = "source"
        if "Url" in cols: mapping["Url"] = "url"
        if "Author" in cols: mapping["Author"] = "author"
        
        report["news_schema"]["mapping"] = mapping
    except Exception as e:
        report["news_schema"]["error"] = str(e)

    # Infer Price
    try:
        if price_file.endswith(".zip"):
            with zipfile.ZipFile(price_file, "r") as z:
                csv_files = [f for f in z.namelist() if f.endswith(".csv") and not f.startswith("__MACOSX")]
                if csv_files:
                    with z.open(csv_files[0]) as f:
                        price_df = pd.read_csv(f, nrows=5)
                        report["price_schema"]["original_columns"] = price_df.columns.tolist()
                        
                        mapping = {}
                        cols = price_df.columns.tolist()
                        # ['Date', 'Open', 'High', 'Low', 'Close', 'Adj Close', 'Volume']
                        for c in cols:
                            lower_c = c.lower()
                            if lower_c == "date": mapping[c] = "date"
                            elif lower_c == "open": mapping[c] = "open"
                            elif lower_c == "high": mapping[c] = "high"
                            elif lower_c == "low": mapping[c] = "low"
                            elif lower_c == "close": mapping[c] = "close"
                            elif "adj" in lower_c and "close" in lower_c: mapping[c] = "adj_close"
                            elif lower_c == "volume": mapping[c] = "volume"
                        
                        report["price_schema"]["mapping"] = mapping
    except Exception as e:
        report["price_schema"]["error"] = str(e)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(report, f, indent=2)

    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
