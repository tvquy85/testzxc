import argparse
import os
import json
from huggingface_hub import snapshot_download

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-id", type=str, required=True)
    parser.add_argument("--repo-type", type=str, default="dataset")
    parser.add_argument("--output", type=str, required=True)
    parser.add_argument("--allow-patterns", type=str, nargs="+", default=["*.csv", "*.parquet", "*.zip"])
    parser.add_argument("--max-files", type=int, default=20)
    args = parser.parse_args()

    print(f"Downloading {args.repo_id} to {args.output}...")
    try:
        path = snapshot_download(
            repo_id=args.repo_id,
            repo_type=args.repo_type,
            local_dir=args.output,
            allow_patterns=args.allow_patterns,
            max_workers=4
        )
        print(f"Downloaded to {path}")
    except Exception as e:
        print(f"Download failed: {e}")

if __name__ == "__main__":
    main()
