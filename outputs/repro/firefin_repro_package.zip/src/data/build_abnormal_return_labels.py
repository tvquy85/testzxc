from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from src.utils.artifacts import write_manifest, write_status


STEP = "05_LABELS_ABNORMAL_RETURN_AND_BALANCE"
LABEL_ORDER = ["strong_down", "mild_down", "neutral", "mild_up", "strong_up"]


def fixed_label(value: float) -> str:
    if value <= -0.03:
        return "strong_down"
    if value <= -0.0075:
        return "mild_down"
    if value < 0.0075:
        return "neutral"
    if value < 0.03:
        return "mild_up"
    return "strong_up"


def make_quantile_labels(series):
    import pandas as pd

    codes = pd.qcut(series.rank(method="first"), q=5, labels=LABEL_ORDER)
    return codes.astype(str)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="data/labels/aligned_samples_h1.parquet")
    parser.add_argument("--splits", default="data/processed/split_membership.parquet")
    parser.add_argument("--horizon", type=int, default=1)
    parser.add_argument("--label-mode", choices=["fixed", "quantile"], default="fixed")
    parser.add_argument("--output", default="data/labels/labels_h1_abnormal.parquet")
    parser.add_argument("--status", default=f"outputs/status/{STEP}.status.json")
    parser.add_argument("--manifest", default=f"outputs/manifests/{STEP}.manifest.json")
    args = parser.parse_args()

    import pandas as pd

    failures: list[str] = []
    df = pd.read_parquet(args.input)
    splits = pd.read_parquet(args.splits)
    if "sample_id" not in df.columns:
        raise ValueError("input must contain sample_id")
    abnormal_col = f"abnormal_return_h{args.horizon}"
    stock_col = f"stock_return_h{args.horizon}"
    market_col = f"market_return_h{args.horizon}"
    if abnormal_col not in df.columns:
        if {stock_col, market_col}.issubset(df.columns):
            df[abnormal_col] = df[stock_col] - df[market_col]
        else:
            raise ValueError(f"Missing {abnormal_col} and cannot derive from {stock_col}/{market_col}")
    out = df.copy()
    out = out.dropna(subset=[abnormal_col]).copy()
    if args.label_mode == "fixed":
        out["label_5"] = out[abnormal_col].apply(fixed_label)
    else:
        out["label_5"] = make_quantile_labels(out[abnormal_col])
    out = out.merge(splits[["sample_id", "split"]], on="sample_id", how="left", validate="one_to_one")
    missing_split = int(out["split"].isna().sum())
    if missing_split:
        failures.append(f"missing split membership for {missing_split} rows")
    legal = set(LABEL_ORDER)
    illegal = sorted(set(out["label_5"].dropna()) - legal)
    if illegal:
        failures.append(f"illegal label values: {illegal}")
    if set(out["label_5"].dropna()) != legal:
        failures.append("label_5 does not contain exactly all 5 legal values")
    if out[abnormal_col].isna().any():
        failures.append("missing abnormal returns in final labeled set")

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    out.to_parquet(args.output, index=False)
    write_manifest(args.manifest, [args.output], STEP)
    status = "PASS" if not failures else "FAIL"
    metrics = {
        "rows": int(len(out)),
        "label_mode": args.label_mode,
        "label_counts": out["label_5"].value_counts().reindex(LABEL_ORDER, fill_value=0).astype(int).to_dict(),
        "split_counts": out["split"].value_counts(dropna=False).astype(int).to_dict(),
        "missing_split": missing_split,
    }
    write_status(
        args.status,
        STEP,
        status,
        inputs_checked=[args.input, args.splits],
        outputs_created=[args.output, args.manifest, args.status],
        metrics=metrics,
        failures=failures,
        next_step_allowed=status == "PASS",
    )
    print(json.dumps(metrics, indent=2, ensure_ascii=False))
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())

