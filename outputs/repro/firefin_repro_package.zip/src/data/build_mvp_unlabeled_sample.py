import os
import json
import zipfile
import pandas as pd
import argparse
from tqdm import tqdm

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="configs/local_paths.yaml")
    parser.add_argument("--tickers-out", type=str, default="data/samples/mvp_tickers.txt")
    parser.add_argument("--limit-tickers", type=int, default=50)
    args = parser.parse_args()

    fallback_tickers = ["AAPL","MSFT","AMZN","GOOGL","META","NVDA","TSLA","JPM","BAC","WMT",
                        "DIS","NFLX","INTC","AMD","IBM","ORCL","CSCO","CRM","BA","GE",
                        "XOM","CVX","PFE","MRK","JNJ","KO","PEP","NKE","MCD","HD",
                        "COST","V","MA","ADBE","QCOM","AVGO","TXN","UNH","PG"]

    manifest = pd.read_csv("data/raw/fnspid_file_manifest.csv")
    price_file = manifest[manifest["guessed_role"] == "price"].iloc[0]["path"]
    news_file = manifest[manifest["guessed_role"] == "news"].iloc[0]["path"]

    # 1. Get available tickers in price data
    available_price_tickers = set()
    if price_file.endswith(".zip"):
        with zipfile.ZipFile(price_file, "r") as z:
            csv_files = [f for f in z.namelist() if f.endswith(".csv") and not f.startswith("__MACOSX")]
            for f in csv_files:
                ticker = os.path.basename(f).replace(".csv", "").upper()
                available_price_tickers.add(ticker)

    # Intersection
    selected_tickers = [t for t in fallback_tickers if t in available_price_tickers]
    selected_tickers = selected_tickers[:args.limit_tickers]

    os.makedirs(os.path.dirname(args.tickers_out), exist_ok=True)
    with open(args.tickers_out, "w") as f:
        f.write("\n".join(selected_tickers))
    print(f"Selected {len(selected_tickers)} tickers for MVP.")

    # 2. Extract Prices
    prices_list = []
    if price_file.endswith(".zip"):
        with zipfile.ZipFile(price_file, "r") as z:
            for t in tqdm(selected_tickers, desc="Extracting Prices"):
                try:
                    with z.open(f"full_history/{t}.csv") as f:
                        df = pd.read_csv(f)
                        df["ticker"] = t
                        
                        # Rename columns
                        cols = df.columns.tolist()
                        mapping = {}
                        for c in cols:
                            lower_c = c.lower()
                            if lower_c == "date": mapping[c] = "date"
                            elif lower_c == "open": mapping[c] = "open"
                            elif lower_c == "high": mapping[c] = "high"
                            elif lower_c == "low": mapping[c] = "low"
                            elif lower_c == "close": mapping[c] = "close"
                            elif "adj" in lower_c and "close" in lower_c: mapping[c] = "adj_close"
                            elif lower_c == "volume": mapping[c] = "volume"
                        
                        df = df.rename(columns=mapping)
                        if "adj_close" not in df.columns:
                            df["adj_close"] = df["close"]
                        df["raw_file"] = price_file
                        df = df[["ticker", "date", "open", "high", "low", "close", "adj_close", "volume", "raw_file"]]
                        
                        # Filter date
                        df["date"] = pd.to_datetime(df["date"], errors="coerce")
                        df = df.dropna(subset=["date", "close", "volume"])
                        df = df[(df["date"] >= "2018-01-01") & (df["date"] <= "2023-12-31")]
                        prices_list.append(df)
                except Exception as e:
                    print(f"Skipping price for {t}: {e}")

    if prices_list:
        prices_df = pd.concat(prices_list, ignore_index=True)
        prices_df = prices_df.sort_values(["ticker", "date"])
        os.makedirs("data/processed", exist_ok=True)
        prices_df.to_parquet("data/processed/prices_mvp.parquet", index=False)
    else:
        prices_df = pd.DataFrame()

    # 3. Extract News
    # Use chunking to read large news file
    chunk_size = 100000
    news_list = []
    
    print("Extracting News...")
    try:
        # Load schema map
        with open("outputs/status/fnspid_schema_report.json", "r") as f:
            schema = json.load(f)
        mapping = schema.get("news_schema", {}).get("mapping", {})
        
        selected_set = set(selected_tickers)
        for chunk in tqdm(pd.read_csv(news_file, chunksize=chunk_size, low_memory=False)):
            chunk = chunk.rename(columns=mapping)
            if "ticker" in chunk.columns:
                chunk = chunk[chunk["ticker"].isin(selected_set)]
                if not chunk.empty:
                    if "body" not in chunk.columns:
                        chunk["body"] = chunk["headline"]
                    if "source" not in chunk.columns:
                        chunk["source"] = "unknown"
                    if "url" not in chunk.columns:
                        chunk["url"] = ""
                    if "author" not in chunk.columns:
                        chunk["author"] = ""
                    
                    chunk["raw_file"] = news_file
                    chunk["news_id"] = chunk.index # naive id
                    
                    # Basic cleaning
                    chunk = chunk.dropna(subset=["ticker", "timestamp_utc"])
                    chunk = chunk.drop_duplicates(subset=["ticker", "timestamp_utc", "headline"])
                    
                    # Convert timestamp
                    chunk["timestamp_utc"] = pd.to_datetime(chunk["timestamp_utc"], errors="coerce", utc=True)
                    chunk = chunk.dropna(subset=["timestamp_utc"])
                    
                    # Filter dates
                    chunk = chunk[(chunk["timestamp_utc"] >= "2018-01-01 00:00:00+00:00") & 
                                  (chunk["timestamp_utc"] <= "2023-12-31 23:59:59+00:00")]
                                  
                    if not chunk.empty:
                        chunk = chunk[["news_id", "ticker", "timestamp_utc", "headline", "body", "source", "url", "author", "raw_file"]]
                        news_list.append(chunk)
    except Exception as e:
        print(f"Error processing news: {e}")

    if news_list:
        news_df = pd.concat(news_list, ignore_index=True)
        # Reset news_id
        news_df["news_id"] = range(len(news_df))
        news_df.to_parquet("data/processed/news_mvp.parquet", index=False)
    else:
        news_df = pd.DataFrame()

    # Status
    status = {
        "step": "03_FNSPID_SCHEMA_AND_SAMPLE_BUILD",
        "status": "PASS" if not news_df.empty and not prices_df.empty else "FAIL",
        "news_rows": len(news_df),
        "price_rows": len(prices_df),
        "ticker_count": prices_df["ticker"].nunique() if not prices_df.empty else 0,
        "date_min": str(prices_df["date"].min())[:10] if not prices_df.empty else None,
        "date_max": str(prices_df["date"].max())[:10] if not prices_df.empty else None,
        "warnings": []
    }
    
    os.makedirs("outputs/status", exist_ok=True)
    with open("outputs/status/03_FNSPID_SCHEMA_AND_SAMPLE_BUILD.status.json", "w") as f:
        json.dump(status, f, indent=2)

    print(json.dumps(status, indent=2))

if __name__ == "__main__":
    main()
