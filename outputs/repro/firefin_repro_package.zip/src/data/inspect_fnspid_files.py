import os
import csv
import json
import yaml
import argparse
from pathlib import Path
import pyarrow.parquet as pq
import zipfile

def guess_role(filename, parent_dir=""):
    lower_name = filename.lower()
    lower_parent = parent_dir.lower()
    if "news" in lower_parent or any(x in lower_name for x in ["news", "headline", "exteral"]):
        return "news"
    elif "price" in lower_parent or any(x in lower_name for x in ["price", "history", "stock", "nasdaq", "nyse"]):
        return "price"
    elif any(x in lower_name for x in ["meta", "company", "ticker"]):
        return "metadata"
    return "unknown"

def create_preview(file_path, suffix, safe_filename, output_dir):
    preview_path = os.path.join(output_dir, f"{safe_filename}.head100.csv")
    if os.path.exists(preview_path):
        return

    try:
        if suffix == ".parquet":
            # read only the first 100 rows
            table = pq.read_table(file_path)
            # if the table is larger than 100 rows, slice it
            if table.num_rows > 100:
                table = table.slice(0, 100)
            df = table.to_pandas()
            df.to_csv(preview_path, index=False)
        elif suffix in [".csv", ".jsonl"]:
            with open(file_path, 'r', encoding='utf-8') as fin, open(preview_path, 'w', encoding='utf-8', newline='') as fout:
                writer = csv.writer(fout)
                reader = csv.reader(fin) if suffix == ".csv" else fin
                for i, row in enumerate(reader):
                    if i >= 100: break
                    if suffix == ".csv":
                        writer.writerow(row)
                    else:
                        fout.write(row if isinstance(row, str) else str(row) + '\n')
        elif suffix == ".zip":
            with zipfile.ZipFile(file_path, 'r') as z:
                names = z.namelist()
                with open(preview_path, 'w', encoding='utf-8') as fout:
                    fout.write("ZIP Contents:\n")
                    for name in names[:100]:
                        fout.write(name + "\n")
    except Exception as e:
        print(f"Failed to create preview for {file_path}: {e}")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="configs/local_paths.yaml")
    parser.add_argument("--output", type=str, default="data/raw/fnspid_file_manifest.csv")
    args = parser.parse_args()

    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)

    fnspid_cache = config.get("datasets", {}).get("fnspid_cache")

    manifest = []
    
    if fnspid_cache and os.path.exists(fnspid_cache):
        for root, dirs, files in os.walk(fnspid_cache):
            for file in files:
                suffix = Path(file).suffix.lower()
                if suffix in [".csv", ".parquet", ".jsonl", ".zip", ".gz"]:
                    file_path = os.path.join(root, file)
                    size_mb = os.path.getsize(file_path) / (1024 * 1024)
                    manifest.append({
                        "path": file_path,
                        "filename": file,
                        "suffix": suffix,
                        "size_mb": round(size_mb, 2),
                        "parent_dir": os.path.basename(root),
                        "guessed_role": guess_role(file, os.path.basename(root))
                    })

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    with open(args.output, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["path", "filename", "suffix", "size_mb", "parent_dir", "guessed_role"])
        writer.writeheader()
        writer.writerows(manifest)

    # Summary
    roles = {}
    for item in manifest:
        roles[item["guessed_role"]] = roles.get(item["guessed_role"], 0) + 1

    summary = {
        "total_files": len(manifest),
        "roles": roles,
        "needs_download": len(manifest) == 0
    }
    
    os.makedirs("outputs/status", exist_ok=True)
    with open("outputs/status/fnspid_file_manifest_summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    # Previews
    os.makedirs("data/raw/previews", exist_ok=True)
    # Sort by size to get largest files for preview
    manifest.sort(key=lambda x: x["size_mb"], reverse=True)
    
    preview_count = 0
    for item in manifest:
        if preview_count >= 5:
            break
        if item["guessed_role"] in ["news", "price"]:
            safe_filename = item["filename"].replace(".", "_")
            create_preview(item["path"], item["suffix"], safe_filename, "data/raw/previews")
            preview_count += 1

    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
