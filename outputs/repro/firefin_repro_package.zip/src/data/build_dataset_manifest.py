from __future__ import annotations

import argparse
import json
import sys
import zipfile
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from src.utils.artifacts import sha256_file, write_json, write_manifest, write_status
from src.utils.config import load_config


STEP = "03_DATA_SCALE_AND_SPLIT_LOCK"


def parquet_rows(path: Path) -> int | None:
    try:
        import pyarrow.parquet as pq

        return int(pq.ParquetFile(path).metadata.num_rows)
    except Exception:
        return None


def csv_header(path: Path) -> list[str]:
    import csv

    with open(path, newline="", encoding="utf-8", errors="replace") as f:
        reader = csv.reader(f)
        return next(reader, [])


def resolve_raw_root(raw_root: str, config_path: str | None, hf_home: str | None) -> Path:
    if hf_home:
        import os

        os.environ["HF_HOME"] = hf_home
    root = Path(raw_root)
    if root.exists():
        return root
    if config_path:
        cfg = load_config(config_path)
        candidate = cfg.get("datasets", {}).get("fnspid_cache")
        if candidate and Path(candidate).exists():
            return Path(candidate)
    return root


def scan_raw(root: Path) -> dict[str, Any]:
    files = sorted([p for p in root.rglob("*") if p.is_file()]) if root.exists() else []
    by_suffix: dict[str, int] = {}
    total_bytes = 0
    for path in files:
        by_suffix[path.suffix.lower() or "<none>"] = by_suffix.get(path.suffix.lower() or "<none>", 0) + 1
        total_bytes += path.stat().st_size

    news_files = [p for p in files if "news" in str(p).lower() or "nasdaq" in p.name.lower()]
    price_files = [p for p in files if "price" in str(p).lower() or "history" in p.name.lower()]
    samples: list[dict[str, Any]] = []
    for path in (news_files + price_files)[:12]:
        item: dict[str, Any] = {
            "path": str(path).replace("\\", "/"),
            "size_bytes": path.stat().st_size,
            "sha256": sha256_file(path) if path.stat().st_size < 200_000_000 else None,
        }
        if path.suffix.lower() == ".csv":
            item["columns"] = csv_header(path)
        if path.suffix.lower() == ".parquet":
            item["row_count"] = parquet_rows(path)
        if path.suffix.lower() == ".zip":
            try:
                with zipfile.ZipFile(path) as zf:
                    item["zip_member_count"] = len(zf.infolist())
                    item["zip_sample_members"] = [info.filename for info in zf.infolist()[:10]]
            except Exception as exc:
                item["zip_error"] = str(exc)
        samples.append(item)

    return {
        "exists": root.exists(),
        "root": str(root).replace("\\", "/"),
        "file_count": len(files),
        "total_bytes": total_bytes,
        "suffix_counts": by_suffix,
        "news_file_count": len(news_files),
        "price_file_count": len(price_files),
        "sample_files": samples,
    }


def scan_processed_cache(cache_root: Path | None) -> dict[str, Any]:
    if not cache_root or not cache_root.exists():
        return {"exists": False}
    news_path = cache_root / "news_thin.parquet"
    prices_dir = cache_root / "prices_by_ticker"
    price_files = sorted(prices_dir.glob("*.parquet")) if prices_dir.exists() else []
    price_rows = 0
    date_min = None
    date_max = None
    for path in price_files:
        rows = parquet_rows(path)
        if rows:
            price_rows += rows
    return {
        "exists": True,
        "root": str(cache_root).replace("\\", "/"),
        "news_thin_rows": parquet_rows(news_path) if news_path.exists() else None,
        "price_ticker_files": len(price_files),
        "price_rows_from_metadata": price_rows,
        "date_min": date_min,
        "date_max": date_max,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-root", default="data/raw/fnspid")
    parser.add_argument("--config", default="configs/default_paths.yaml")
    parser.add_argument("--hf-home", default=None)
    parser.add_argument("--output", default="outputs/manifests/fnspid_dataset_manifest.json")
    parser.add_argument("--status", default=f"outputs/status/{STEP}.status.json")
    parser.add_argument("--manifest", default=f"outputs/manifests/{STEP}.manifest.json")
    args = parser.parse_args()

    failures: list[str] = []
    root = resolve_raw_root(args.raw_root, args.config, args.hf_home)
    cfg = load_config(args.config) if Path(args.config).exists() else {}
    cache_root_value = cfg.get("datasets", {}).get("fnspid_cache_processed")
    cache_root = Path(cache_root_value) if cache_root_value else None
    raw = scan_raw(root)
    cache = scan_processed_cache(cache_root)
    if not raw["exists"]:
        failures.append(
            f"FNSPID raw root not found: {args.raw_root}. Set HF_HOME or pass --raw-root to the local FNSPID cache."
        )

    aligned_rows = None
    ticker_count = None
    aligned_path = Path("data/labels/aligned_samples_h1.parquet")
    if aligned_path.exists():
        import pandas as pd

        aligned = pd.read_parquet(aligned_path, columns=["ticker", "event_date"])
        aligned_rows = int(len(aligned))
        ticker_count = int(aligned["ticker"].nunique())

    metrics = {
        "ticker_count": ticker_count,
        "aligned_candidate_rows": aligned_rows,
        "mvp_gate": bool((ticker_count or 0) >= 36 and (aligned_rows or 0) >= 100000),
        "aaai_target_gate": bool((ticker_count or 0) >= 300 and (aligned_rows or 0) >= 500000),
    }
    report = {
        "step": STEP,
        "raw_scan": raw,
        "processed_cache_scan": cache,
        "metrics": metrics,
        "download_instructions": None
        if raw["exists"]
        else "Use the local FNSPID cache under HF_HOME/datasets/fnspid_official or download Zihan1004/FNSPID.",
    }
    write_json(args.output, report)
    write_manifest(args.manifest, [args.output], STEP)
    status = "PASS" if not failures and metrics["mvp_gate"] else "FAIL"
    if not metrics["mvp_gate"]:
        failures.append("MVP scale gate not met: tickers >= 36 and aligned candidate rows >= 100000")
    write_status(
        args.status,
        STEP,
        status,
        inputs_checked=[str(root), "data/labels/aligned_samples_h1.parquet"],
        outputs_created=[args.output, args.manifest, args.status],
        metrics=metrics,
        failures=failures,
        next_step_allowed=status == "PASS",
    )
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())

