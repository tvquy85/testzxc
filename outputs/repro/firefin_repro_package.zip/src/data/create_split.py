import os
import argparse
import pandas as pd
import numpy as np

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--samples", type=str, default="data/labels/aligned_samples_h1.parquet")
    parser.add_argument("--output", type=str, default="data/processed/split_h1.parquet")
    args = parser.parse_args()

    df = pd.read_parquet(args.samples)
    dates = np.sort(df["event_date"].dt.date.unique())
    n = len(dates)
    train_end_date = dates[int(n * 0.7) - 1]
    val_end_date = dates[int(n * 0.85) - 1]

    def get_split(d):
        d_date = d.date()
        if d_date <= train_end_date: return "train"
        elif d_date <= val_end_date: return "val"
        else: return "test"

    df["split"] = df["event_date"].apply(get_split)
    
    out_df = df[["sample_id", "split"]]
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    out_df.to_parquet(args.output, index=False)
    
    print(df["split"].value_counts(normalize=True))
    print(f"Split assignment saved to {args.output}")

if __name__ == "__main__":
    main()
